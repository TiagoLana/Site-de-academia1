function verificarCampoNome() {

    var aux = document.getElementById("inome").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("inome").style.backgroundColor = "red";
        document.getElementById("inomeerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("0") || aux.includes("1") || aux.includes("2") || aux.includes("3") || aux.includes("4") || aux.includes("5")
             || aux.includes("6") || aux.includes("7") || aux.includes("8") || aux.includes("9")) {
            document.getElementById("inome").style.backgroundColor = "red";

            document.getElementById("inomeerro").innerHTML = "Erro. Voce colocou caracteres numericos";
        } else {

            if (aux.includes(".") || aux.includes(",") || aux.includes(";") || aux.includes("-") || aux.includes(":") || aux.includes("¨")
                 || aux.includes("{") || aux.includes("}") || aux.includes("+") || aux.includes("^") || aux.includes("*") || aux.includes("%")
                 || aux.includes("?") || aux.includes("=") || aux.includes("!") || aux.includes("$") || aux.includes("#") || aux.includes("ª")
                 || aux.includes("º") || aux.includes("|")) {
                document.getElementById("inome").style.backgroundColor = "red";
                document.getElementById("inomeerro").innerHTML = "Erro. Voce colocou caracteres invalidos";

            } else {
                document.getElementById("inome").style.backgroundColor = "aliceblue";
                document.getElementById("inomeerro").innerHTML = "";
            }
        }
    }
    document.getElementById("inome").value = aux;
}


function verificarCampoTelefone() {

    var aux = document.getElementById("itelefone").value;

    if (aux == null || aux == "") {

        document.getElementById("itelefone").style.backgroundColor = "red";
        document.getElementById("itelefoneerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.length != 11) {
            document.getElementById("itelefone").style.backgroundColor = "red";
            document.getElementById("itelefoneerro").innerHTML = "Erro. Você digitou uma quantidade invalida de caracteres permitidos";
        } else {
            document.getElementById("itelefone").style.backgroundColor = "aliceblue";
            document.getElementById("itelefoneerro").innerHTML = "";
        }
    }
}


function verificarCampoEmail() {

    var aux = document.getElementById("iemail").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("iemail").style.backgroundColor = "red";
        document.getElementById("iemailerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("@") && aux.includes(".com")) {

            document.getElementById("iemail").style.backgroundColor = "aliceblue";
            document.getElementById("iemailerro").innerHTML = "";
        } else {
            document.getElementById("iemail").style.backgroundColor = "red";
            document.getElementById("iemailerro").innerHTML = "Erro. Você digitou um email invalido";

        }
    }
    aux = document.getElementById("iemail").value;
}


function verificarMensagem() {

    var aux = document.getElementById("texto1").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("texto1").style.backgroundColor = "red";
        document.getElementById("mensagemerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("0") || aux.includes("1") || aux.includes("2") || aux.includes("3") || aux.includes("4") || aux.includes("5")
             || aux.includes("6") || aux.includes("7") || aux.includes("8") || aux.includes("9")) {
            document.getElementById("texto1").style.backgroundColor = "red";

            document.getElementById("mensagemerro").innerHTML = "Erro. Voce colocou caracteres numericos";
        } else {

            if (aux.includes(".") || aux.includes(",") || aux.includes(";") || aux.includes("-") || aux.includes(":") || aux.includes("¨")
                 || aux.includes("{") || aux.includes("}") || aux.includes("+") || aux.includes("^") || aux.includes("*") || aux.includes("%")
                 || aux.includes("?") || aux.includes("=") || aux.includes("!") || aux.includes("$") || aux.includes("#") || aux.includes("ª")
                 || aux.includes("º") || aux.includes("|")) {
                document.getElementById( "texto1").style.backgroundColor = "red";
                document.getElementById("inomeerro").innerHTML = "Erro. Voce colocou caracteres invalidos";

            } else {
                document.getElementById("texto1").style.backgroundColor = "aliceblue";
                document.getElementById("mensagemerro").innerHTML = "";
            }
        }
    }
    document.getElementById("texto1").value = aux;
}