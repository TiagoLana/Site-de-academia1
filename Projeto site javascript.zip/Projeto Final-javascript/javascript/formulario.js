var i = 0;
var vetorImagem = [];

vetorImagem.push("../imagens/agua.jpg");
vetorImagem.push("../imagens/criancas-sorrindo.jpg");
vetorImagem.push("../imagens/cesta.jpg");
vetorImagem.push("../imagens/fundodocorpo.jpg");
vetorImagem.push("../imagens/criancas.jpg")



function anterior() {
    i--;
    document.getElementById("itela").src = vetorImagem[i];
}

function proximo() {
    i++;
    document.getElementById("itela").src = vetorImagem[i];
}

function anterior1() {
    i--;
    if (i < 0) {




        document.getElementById("itela").src = vetorImagem[vetorImagem.length - 1];

    } else {
        document.getElementById("itela").src = vetorImagem[i];

    }


}

function proximo1() {
    i++;

 

    if (i => vetorImagem.length()) {

       



        document.getElementById("itela").src = vetorImagem[i];

    } else {
        document.getElementById("itela").src = vetorImagem[vetorImagem.length - 1];

    }
}






function aoDigitarCpf() {
    //chamada no onkeypress
    var aux = document.getElementById("icpf").value;
    if (aux.length == 3) {
        aux = aux + ".";
        document.getElementById("icpf").value = aux;

    }
    if (aux.length == 7) {
        aux = aux + ".";
        document.getElementById("icpf").value = aux;

    }
    if (aux.length == 11) {
        aux = aux + "-";
        document.getElementById("icpf").value = aux;

    }
    if (aux.length > 14) {

        document.getElementById("ierro").innerHTML = "Erro";
        document.getElementById("icpf").max.length = aux;

    }

    aux = aux.replace("..", ".");
    aux = aux.replace("--", "-");
    document.getElementById("icpf").value = aux;

}
function verificarCpf() {
    //evento onblur
    var aux = document.getElementById("icpf").value;
    if (aux.length == 11) {
        document.getElementById("ierro").innerHTML = "OK";
        document.getElementById("icpf").style.backgroundColor = "green";

    } else {

        if (aux.length == 14 && verificarCom14(aux)) {
            document.getElementById("ierro").innerHTML = "";
            document.getElementById("icpf").style.backgroundColor = "blue";

        } else {
            document.getElementById("ierro").innerHTML = "Cpf inválido,tente novamente";
            document.getElementById("ierro").style.color = "red";

        }
    }

}
function verificarCom11(cpf) {
    var contadorN = 0;

    for (var i = 0; i < cpf.length; i++) {
        var aux2 = cpf.charAt(i);

        switch (aux2) {
        case "0":
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
            contadorN++;
            break;

        }
    }
    if (contadorN == 11) {
        return true;

    } else {
        return false;
    }
}
function verificarCom14(cpf) {
    var contadorN = 0;
    var contadorP = 0;
    var contadorT = 0;
    for (var i = 0; i < cpf.length; i++) {
        var aux2 = cpf.charAt(i);

        switch (aux2) {
        case "0":
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
            contadorN++;
            break;
        case ".":

            contadorP++;
            break;
        case "-":
            contadorT++;
            break;
        }
    }
    if (contadorN == 11 && contadorP == 2 && contadorT == 1 && cpf.charAt(3) == "." && cpf.charAt(7) == "." && cpf.charAt(11) == "-") {
        return true;

    } else {
        return false;
    }
}

function verificarCampoNome() {

    var aux = document.getElementById("inome").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("inome").style.backgroundColor = "red";
        document.getElementById("inomeerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("0") || aux.includes("1") || aux.includes("2") || aux.includes("3") || aux.includes("4") || aux.includes("5")
             || aux.includes("6") || aux.includes("7") || aux.includes("8") || aux.includes("9")) {
            document.getElementById("inome").style.backgroundColor = "red";

            document.getElementById("inomeerro").innerHTML = "Erro. Voce colocou caracteres numericos";
        } else {

            if (aux.includes(".") || aux.includes(",") || aux.includes(";") || aux.includes("-") || aux.includes(":") || aux.includes("¨")
                 || aux.includes("{") || aux.includes("}") || aux.includes("+") || aux.includes("^") || aux.includes("*") || aux.includes("%")
                 || aux.includes("?") || aux.includes("=") || aux.includes("!") || aux.includes("$") || aux.includes("#") || aux.includes("ª")
                 || aux.includes("º") || aux.includes("|")) {
                document.getElementById("inome").style.backgroundColor = "red";
                document.getElementById("inomeerro").innerHTML = "Erro. Voce colocou caracteres invalidos";

            } else {
                document.getElementById("inome").style.backgroundColor = "aliceblue";
                document.getElementById("inomeerro").innerHTML = "";
            }
        }
    }
    document.getElementById("inome").value = aux;
}


function verificarCampoNomePai() {

    var aux = document.getElementById("inomepai").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("inomepai").style.backgroundColor = "red";
        document.getElementById("nomepaierro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("0") || aux.includes("1") || aux.includes("2") || aux.includes("3") || aux.includes("4") || aux.includes("5")
             || aux.includes("6") || aux.includes("7") || aux.includes("8") || aux.includes("9")) {
            document.getElementById("inomepai").style.backgroundColor = "red";

            document.getElementById("nomepaierro").innerHTML = "Erro. Voce colocou caracteres numericos";
        } else {

            if (aux.includes(".") || aux.includes(",") || aux.includes(";") || aux.includes("-") || aux.includes(":") || aux.includes("¨")
                 || aux.includes("{") || aux.includes("}") || aux.includes("+") || aux.includes("^") || aux.includes("*") || aux.includes("%")
                 || aux.includes("?") || aux.includes("=") || aux.includes("!") || aux.includes("$") || aux.includes("#") || aux.includes("ª")
                 || aux.includes("º") || aux.includes("|")) {
                document.getElementById("inomepai").style.backgroundColor = "red";
                document.getElementById("nomepaierro").innerHTML = "Erro. Voce colocou caracteres invalidos";

            } else {
                document.getElementById("inomepai").style.backgroundColor = "aliceblue";
                document.getElementById("nomepaierro").innerHTML = "";
            }
        }
    }
    document.getElementById("inomepai").value = aux;
}



function verificarCampoNomeMae() {

    var aux = document.getElementById("inomemae").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("inomemae").style.backgroundColor = "red";
        document.getElementById("nomemaeerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("0") || aux.includes("1") || aux.includes("2") || aux.includes("3") || aux.includes("4") || aux.includes("5")
             || aux.includes("6") || aux.includes("7") || aux.includes("8") || aux.includes("9")) {
            document.getElementById("inomemae").style.backgroundColor = "red";

            document.getElementById("nomemaeerro").innerHTML = "Erro. Voce colocou caracteres numericos";
        } else {

            if (aux.includes(".") || aux.includes(",") || aux.includes(";") || aux.includes("-") || aux.includes(":") || aux.includes("¨")
                 || aux.includes("{") || aux.includes("}") || aux.includes("+") || aux.includes("^") || aux.includes("*") || aux.includes("%")
                 || aux.includes("?") || aux.includes("=") || aux.includes("!") || aux.includes("$") || aux.includes("#") || aux.includes("ª")
                 || aux.includes("º") || aux.includes("|")) {
                document.getElementById("inomemae").style.backgroundColor = "red";
                document.getElementById("nomemaeerro").innerHTML = "Erro. Voce colocou caracteres invalidos";

            } else {
                document.getElementById("inomemae").style.backgroundColor = "aliceblue";
                document.getElementById("nomemaeerro").innerHTML = "";
            }
        }
    }
    document.getElementById("inomemae").value = aux;
}

function verificarCampoTelefone() {

    var aux = document.getElementById("itelefone").value;

    if (aux == null || aux == "") {

        document.getElementById("itelefone").style.backgroundColor = "red";
        document.getElementById("itelefoneerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.length != 14) {
            document.getElementById("itelefone").style.backgroundColor = "red";
            document.getElementById("itelefoneerro").innerHTML = "Erro. Você digitou uma quantidade invalida de caracteres permitidos";
        } else {
            document.getElementById("itelefone").style.backgroundColor = "aliceblue";
            document.getElementById("itelefoneerro").innerHTML = "";
        }
    }
}


function verificarCampoEmail() {

    var aux = document.getElementById("iemail").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("iemail").style.backgroundColor = "red";
        document.getElementById("iemailerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("@") && aux.includes(".com")) {

            document.getElementById("iemail").style.backgroundColor = "aliceblue";
            document.getElementById("iemailerro").innerHTML = "";
        } else {
            document.getElementById("iemail").style.backgroundColor = "red";
            document.getElementById("iemailerro").innerHTML = "Erro. Você digitou um email invalido";

        }
    }
    aux = document.getElementById("iemail").value;
}


function verificarCampoBairro() {

    var aux = document.getElementById("ibairro").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("ibairro").style.backgroundColor = "red";
        document.getElementById("bairroerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("0") || aux.includes("1") || aux.includes("2") || aux.includes("3") || aux.includes("4") || aux.includes("5")
            || aux.includes("6") || aux.includes("7") || aux.includes("8") || aux.includes("9")) {
            document.getElementById("ibairro").style.backgroundColor = "red";

            document.getElementById("bairroerro").innerHTML = "Erro. Voce colocou caracteres numericos";
        } else {

            if (aux.includes(".") || aux.includes(",") || aux.includes(";") || aux.includes("-") || aux.includes(":") || aux.includes("¨")
                || aux.includes("{") || aux.includes("}") || aux.includes("+") || aux.includes("^") || aux.includes("*") || aux.includes("%")
                || aux.includes("?") || aux.includes("=") || aux.includes("!") || aux.includes("$") || aux.includes("#") || aux.includes("ª")
                || aux.includes("º") || aux.includes("|")) {
                document.getElementById("ibairro").style.backgroundColor = "red";
                document.getElementById("bairroerro").innerHTML = "Erro. Voce colocou caracteres invalidos";

            } else {
                document.getElementById("ibairro").style.backgroundColor = "aliceblue";
                document.getElementById("bairroerro").innerHTML = "";
            }
        }
    }
    document.getElementById("ibairro").value = aux;
}




function verificarCampoCidade() {

    var aux = document.getElementById("icidade").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("icidade").style.backgroundColor = "red";
        document.getElementById("icidadeeerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("0") || aux.includes("1") || aux.includes("2") || aux.includes("3") || aux.includes("4") || aux.includes("5")
            || aux.includes("6") || aux.includes("7") || aux.includes("8") || aux.includes("9")) {
            document.getElementById("icidade").style.backgroundColor = "red";

            document.getElementById("icidadeeerro").innerHTML = "Erro. Voce colocou caracteres numericos";
        } else {

            if (aux.includes(".") || aux.includes(",") || aux.includes(";") || aux.includes("-") || aux.includes(":") || aux.includes("¨")
                || aux.includes("{") || aux.includes("}") || aux.includes("+") || aux.includes("^") || aux.includes("*") || aux.includes("%")
                || aux.includes("?") || aux.includes("=") || aux.includes("!") || aux.includes("$") || aux.includes("#") || aux.includes("ª")
                || aux.includes("º") || aux.includes("|")) {
                document.getElementById("icidade").style.backgroundColor = "red";
                document.getElementById("icidadeeerro").innerHTML = "Erro. Voce colocou caracteres invalidos";

            } else {
                document.getElementById("icidade").style.backgroundColor = "aliceblue";
                document.getElementById("icidadeeerro").innerHTML = "";
            }
        }
    }
    document.getElementById("icidade").value = aux;
}


function aoDigitarTel() {
    //chamada no onkeypress
    var aux = document.getElementById("itelefone").value;
    if (aux.length == 0) {
        aux = aux + "(";
        document.getElementById("itelefone").value = aux;

    }
    if (aux.length == 3) {
        aux = aux + ")";
        document.getElementById("itelefone").value = aux;

    }
    if (aux.length == 9) {
        aux = aux + "-";
        document.getElementById("itelefone").value = aux;

    }
    if (aux.length < 14) {

        document.getElementById("itelefoneerro").innerHTML = "Erro";
        document.getElementById("itelefone").max.length = aux;

    }
}






function aoDigitarRg() {
    //chamada no onkeypress
    var aux = document.getElementById("iidentidade").value;
    if (aux.length == 2) {
        aux = aux + ".";
        document.getElementById("iidentidade").value = aux;

    }
    if (aux.length == 6) {
        aux = aux + ".";
        document.getElementById("iidentidade").value = aux;

    }
    if (aux.length == 10) {
        aux = aux + "-";
        document.getElementById("iidentidade").value = aux;

    }
    if (aux.length < 12) {

        document.getElementById("identidadeerro").innerHTML = "Erro";
        document.getElementById("iidentidade").max.length = aux;

    }

    aux = aux.replace("..", ".");
    aux = aux.replace("--", "-");
    document.getElementById("iidentidade").value = aux;

}
function verificarRg() {
    //evento onblur

    var aux = document.getElementById("icpf").value;
        if (aux.length == 12 && verificarCom12(aux)) {
            document.getElementById("identidadeerro").innerHTML = "";
            document.getElementById("iidentidade").style.backgroundColor = "blue";

        } else {
            document.getElementById("identidadeerro").innerHTML = "Rg inválido,tente novamente";
            document.getElementById("identidadeerro").style.color = "red";

        }
    }


   
function verificarCom12(rg) {
    var contadorN = 0;
    var contadorP = 0;
    var contadorT = 0;
    for (var i = 0; i < rg.length; i++) {
        var aux2 = rg.charAt(i);

        switch (aux2) {
        case "0":
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
            contadorN++;
            break;
        case ".":

            contadorP++;
            break;
        case "-":
            contadorT++;
            break;
        }
    }
    if (contadorN == 9 && contadorP == 2 && contadorT == 1 && rg.charAt(2) == "." && rg.charAt(6) == "." && rg.charAt(10) == "-") {
        return true;

    } else {
        return false;
    }
}

function verificarCampoEndereco() {

    var aux = document.getElementById("irua").value.trim();

    if (aux == null || aux == "") {

        document.getElementById("irua").style.backgroundColor = "red";
        document.getElementById("enderecoeerro").innerHTML = "Erro. Você deixou o campo em branco";
    } else {

        if (aux.includes("0") || aux.includes("1") || aux.includes("2") || aux.includes("3") || aux.includes("4") || aux.includes("5")
             || aux.includes("6") || aux.includes("7") || aux.includes("8") || aux.includes("9")) {
            document.getElementById("irua").style.backgroundColor = "red";

            document.getElementById("enderecoeerro").innerHTML = "Erro. Voce colocou caracteres numericos";
        } else {

            if (aux.includes(".") || aux.includes(",") || aux.includes(";") || aux.includes("-") || aux.includes(":") || aux.includes("¨")
                 || aux.includes("{") || aux.includes("}") || aux.includes("+") || aux.includes("^") || aux.includes("*") || aux.includes("%")
                 || aux.includes("?") || aux.includes("=") || aux.includes("!") || aux.includes("$") || aux.includes("#") || aux.includes("ª")
                 || aux.includes("º") || aux.includes("|")) {
                document.getElementById("irua").style.backgroundColor = "red";
                document.getElementById("enderecoeerro").innerHTML = "Erro. Voce colocou caracteres invalidos";

            } else {
                document.getElementById("irua").style.backgroundColor = "aliceblue";
                document.getElementById("enderecoeerro").innerHTML = "";
            }
        }
    }
    document.getElementById("irua").value = aux;
}




